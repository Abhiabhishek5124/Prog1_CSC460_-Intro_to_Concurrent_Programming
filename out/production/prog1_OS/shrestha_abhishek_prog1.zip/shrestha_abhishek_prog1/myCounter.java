class myCounter {
    protected int total;

    public myCounter(int total) {
        this.total = total;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int val) {
        this.total = val;
    }
}